package containers;

public enum BeaconType {
    /**
     * not ibeacon device
     */
    NOT_A_BEACON,
    /**
     * ibeacon device
     * */
    IBEACON,
}
