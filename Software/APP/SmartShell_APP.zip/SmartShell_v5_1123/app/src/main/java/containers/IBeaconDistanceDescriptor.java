package containers;

public enum IBeaconDistanceDescriptor {
    IMMEDIATE,
    NEAR,
    FAR,
    UNKNOWN,
}
