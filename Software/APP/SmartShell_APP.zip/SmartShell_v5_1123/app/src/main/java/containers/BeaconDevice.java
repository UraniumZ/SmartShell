package containers;

public interface BeaconDevice {
    BeaconType getBeaconType();
}
